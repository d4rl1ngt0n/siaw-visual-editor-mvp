# Order Siaw Manufacturing Website V32

V32 uses the uploaded media for the Featured Projects / AgriSense section.

## Important
No images or videos were regenerated in this version.

## New in V32
- Used uploaded 1.jpg as the main AgriSense / Featured Projects image.
- Used uploaded 1.jpg, 2.jpg and 3.jpg as the AgriSense mini gallery images.
- Used uploaded 4.mp4 as the AgriSense demo video.
- Compressed the uploaded images into WebP for faster loading.
- Compressed the uploaded video into a web-friendly MP4.
- Added a video poster image extracted from the uploaded video.
- The AgriSense Project Spotlight now shows the demo video and can play it.

## Kept from previous version
- Why Work With Us fixes.
- Exact Google Maps link.
- Updated email.
- Request form message templates.
- Footer, CTA, mobile polish and SEO work.

## How to test
1. Extract the ZIP.
2. Open index.html with Live Server.
3. Go to Featured Projects.
4. Check AgriSense.
5. Confirm the new uploaded images appear.
6. Click Play demo video and test the video.
