// Mobile menu
const menuBtn = document.getElementById("menuBtn");
const navLinks = document.getElementById("navLinks");

if (menuBtn) {
  menuBtn.addEventListener("click", () => {
    navLinks.classList.toggle("show");
  });
}

// Footer year
document.getElementById("year").textContent = new Date().getFullYear();

// About focus details
const focusTriggers = document.querySelectorAll(".interactive-list .info-trigger");
const focusPanel = document.getElementById("focusPanel");

focusTriggers.forEach((btn) => {
  btn.addEventListener("click", () => {
    focusTriggers.forEach((item) => item.classList.remove("active"));
    btn.classList.add("active");
    focusPanel.innerHTML = `<h4>${btn.dataset.title}</h4><p>${btn.dataset.text}</p>`;
  });
});

// Shared popup modal
const modal = document.getElementById("infoModal");
const modalOverlay = document.getElementById("modalOverlay");
const modalClose = document.getElementById("modalClose");
const modalTitle = document.getElementById("modalTitle");
const modalText = document.getElementById("modalText");
const modalImage = document.getElementById("modalImage");
const cardTriggers = document.querySelectorAll(".info-trigger-card");

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function openModal(title, text, imagePath, extraHtml = "") {
  modalTitle.textContent = title;
  modalText.innerHTML = `<p>${escapeHtml(text)}</p>${extraHtml}`;
  modalImage.onerror = () => {
    modalImage.onerror = null;
    modalImage.src = "images/about-us.webp";
  };
  modalImage.src = imagePath;
  modal.classList.add("show");
  modal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
}

function closeModal() {
  modal.classList.remove("show");
  modal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}


// V22 expanded content for "From idea to working product"
const processExpandedContent = {
  "Discuss Your Idea": `
    <div class="modal-detail-grid">
      <div class="modal-detail-section">
        <h4>What happens here</h4>
        <p>We sit with you to understand the product idea, the problem you want to solve, the people who will use it, the stage you are currently at and the result you expect. This helps us know whether your idea should begin as a sketch, CAD concept, prototype, automation workflow, training package or manufacturing support project.</p>
      </div>

      <div class="modal-detail-section">
        <h4>What we need from you</h4>
        <ul>
          <li>Your product or project idea</li>
          <li>The problem you want to solve</li>
          <li>Target users or customers</li>
          <li>Any sketches, photos, videos or references</li>
          <li>Your budget range and preferred timeline</li>
        </ul>
      </div>

      <div class="modal-detail-section">
        <h4>What you get after this stage</h4>
        <p>You get a clearer project direction, the recommended next step, and an understanding of whether we should move into design, prototyping, automation, training or production planning.</p>
      </div>
    </div>
  `,
  "Design & Plan": `
    <div class="modal-detail-grid">
      <div class="modal-detail-section">
        <h4>What happens here</h4>
        <p>After understanding the idea, we prepare the development direction. This may include sketches, CAD concepts, material suggestions, component selection, product structure, workflow mapping, cost considerations and a simple roadmap for building the solution.</p>
      </div>

      <div class="modal-detail-section">
        <h4>What we focus on</h4>
        <ul>
          <li>Product shape, size, function and user experience</li>
          <li>Technical design direction</li>
          <li>Materials, parts and possible suppliers</li>
          <li>Prototype approach and testing plan</li>
          <li>Cost-saving and practical production options</li>
        </ul>
      </div>

      <div class="modal-detail-section">
        <h4>What you get after this stage</h4>
        <p>You get a more organized plan before building starts. This reduces confusion, avoids unnecessary cost and gives the prototype or solution a clear technical path.</p>
      </div>
    </div>
  `,
  "Build & Test": `
    <div class="modal-detail-grid">
      <div class="modal-detail-section">
        <h4>What happens here</h4>
        <p>We help develop the first working sample, prototype, automation workflow or technical setup. After building, we test the function, review what works, identify weak points and collect feedback for improvement.</p>
      </div>

      <div class="modal-detail-section">
        <h4>What we check</h4>
        <ul>
          <li>Does the prototype perform the expected function?</li>
          <li>Is the design practical for real users?</li>
          <li>Are there weak parts, errors or safety issues?</li>
          <li>Can the cost, size or material choice be improved?</li>
          <li>What needs to change before the next version?</li>
        </ul>
      </div>

      <div class="modal-detail-section">
        <h4>What you get after this stage</h4>
        <p>You get a tested version of the idea and clear feedback on what must be improved before demonstration, pilot use, market testing or small-scale production.</p>
      </div>
    </div>
  `,
  "Improve & Produce": `
    <div class="modal-detail-grid">
      <div class="modal-detail-section">
        <h4>What happens here</h4>
        <p>After testing, we improve the design, materials, structure, electronics, workflow or system. We then prepare the product or solution for pilot testing, customer demonstration, small-scale production or future manufacturing support.</p>
      </div>

      <div class="modal-detail-section">
        <h4>What we improve</h4>
        <ul>
          <li>Product strength, appearance and usability</li>
          <li>Material and component choices</li>
          <li>Assembly method and production process</li>
          <li>Packaging, presentation or demo readiness</li>
          <li>Readiness for market feedback or institutional use</li>
        </ul>
      </div>

      <div class="modal-detail-section">
        <h4>What you get after this stage</h4>
        <p>You get a more reliable and presentable solution that can be used for demonstrations, customer conversations, pilot testing, proposals, competitions or early production planning.</p>
      </div>
    </div>
  `
};


// V23 expanded content for Our Services
const serviceExpandedContent = {
  engineering: {
    title: "Engineering Consultancy",
    image: "images/service-engineering-consultancy.webp",
    summary: "Technical guidance for startups, SMEs, students and institutions that need a clearer path before building or manufacturing a product.",
    details: `
      <div class="modal-detail-grid">
        <div class="modal-detail-section">
          <h4>What we help with</h4>
          <p>We help you review your idea or existing product from a technical angle. This includes checking feasibility, materials, product structure, expected function, development route and what needs to be solved before prototyping or production.</p>
        </div>

        <div class="modal-detail-section">
          <h4>Examples of support</h4>
          <ul>
            <li>Product feasibility review and technical advice</li>
            <li>Material, component and production approach guidance</li>
            <li>Cost-saving suggestions before development starts</li>
            <li>Engineering direction for prototypes, devices and product ideas</li>
            <li>Review of existing product problems and improvement options</li>
          </ul>
        </div>

        <div class="modal-detail-section">
          <h4>What you get</h4>
          <p>You get practical recommendations, a clearer technical direction and a better understanding of what steps are needed to move your idea or product forward safely and affordably.</p>
        </div>
      </div>
    `
  },

  prototyping: {
    title: "Prototyping & Testing",
    image: "images/service-prototyping-testing.webp",
    summary: "Support for building early samples, functional prototypes and testing them before committing to full production.",
    details: `
      <div class="modal-detail-grid">
        <div class="modal-detail-section">
          <h4>What we help with</h4>
          <p>We support the process of turning a design or idea into a first working sample. After building, we test the prototype, identify weaknesses, collect feedback and help improve the next version.</p>
        </div>

        <div class="modal-detail-section">
          <h4>Examples of support</h4>
          <ul>
            <li>Concept models and physical prototype support</li>
            <li>Electronics, sensors, enclosures or mechanical sample support</li>
            <li>Prototype testing and feedback review</li>
            <li>Identifying design, material, usability or safety issues</li>
            <li>Preparing the prototype for demo, pitch or pilot testing</li>
          </ul>
        </div>

        <div class="modal-detail-section">
          <h4>What you get</h4>
          <p>You get a tested prototype direction, clearer improvement notes and a better version of the product before spending more money on production or market launch.</p>
        </div>
      </div>
    `
  },

  product: {
    title: "Product Development",
    image: "images/service-product-development.webp",
    summary: "A practical development path from idea refinement to design, prototype planning, testing and preparation for market or production.",
    details: `
      <div class="modal-detail-grid">
        <div class="modal-detail-section">
          <h4>What we help with</h4>
          <p>We help shape your product idea into something that can be designed, tested, improved and presented properly. This may include design thinking, CAD direction, prototype planning, product features, use cases and production readiness.</p>
        </div>

        <div class="modal-detail-section">
          <h4>Examples of support</h4>
          <ul>
            <li>Idea refinement and product concept development</li>
            <li>Product feature planning and user-focused improvements</li>
            <li>CAD/product design direction and technical planning</li>
            <li>Prototype-to-market development roadmap</li>
            <li>Support for pitch, demo, proposal or pilot product readiness</li>
          </ul>
        </div>

        <div class="modal-detail-section">
          <h4>What you get</h4>
          <p>You get a clearer product development plan and support to move from rough idea to a more practical, testable and presentable product.</p>
        </div>
      </div>
    `
  },

  mentorship: {
    title: "Mentorship & Training",
    image: "images/service-mentorship-training.webp",
    summary: "Training and mentorship for students, startups, SMEs and teams who want to learn product development, prototyping and innovation skills.",
    details: `
      <div class="modal-detail-grid">
        <div class="modal-detail-section">
          <h4>What we help with</h4>
          <p>We guide individuals and teams through practical innovation, engineering, prototyping, automation and product-building processes. The focus is hands-on learning and real project improvement.</p>
        </div>

        <div class="modal-detail-section">
          <h4>Examples of support</h4>
          <ul>
            <li>Startup product mentorship and idea development</li>
            <li>Student innovation and prototype coaching</li>
            <li>Hands-on technical workshops and maker training</li>
            <li>Support with Arduino, sensors, IoT and automation concepts</li>
            <li>Guidance for competitions, project demos and technical presentations</li>
          </ul>
        </div>

        <div class="modal-detail-section">
          <h4>What you get</h4>
          <p>You get practical guidance, clearer technical understanding and support to improve your project, product idea or innovation skills.</p>
        </div>
      </div>
    `
  }
};

const serviceDetailTriggers = document.querySelectorAll(".service-detail-trigger");

serviceDetailTriggers.forEach((card) => {
  const openServiceDetails = () => {
    const service = serviceExpandedContent[card.dataset.service];
    if (!service) return;
    openModal(service.title, service.summary, service.image, service.details);
  };

  card.addEventListener("click", openServiceDetails);

  card.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      openServiceDetails();
    }
  });
});


cardTriggers.forEach((card) => {
  card.addEventListener("click", () => {
    const extraHtml = processExpandedContent[card.dataset.title] || "";
    openModal(card.dataset.title, card.dataset.text, card.dataset.image, extraHtml);
  });
});

modalOverlay.addEventListener("click", closeModal);
modalClose.addEventListener("click", closeModal);

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closeModal();
});



// V8 Project spotlight data
const projectData = {
  agrisense: {
    label: "Project 01",
    title: "AgriSense",
    image: "images/project-agrisense.webp",
    video: "videos/agrisense-demo.mp4",
    poster: "images/agrisense-video-poster.webp",
    text: "AgriSense is a smart agriculture monitoring solution concept designed to help farmers, students, researchers and agribusinesses understand soil, farm and growing conditions better. The new project media shows real AgriSense testing and demonstration in hydroponic, farm and aquaculture-related environments.",
    points: ["Real field testing", "Smart agriculture", "Hydroponics & farm use", "Demo video available"],
    gallery: ["images/agrisense-gallery-1.webp", "images/agrisense-gallery-2.webp", "images/agrisense-gallery-3.webp"],
    details: `
      <div class="modal-detail-grid project-detail-grid">
        <div class="modal-detail-section">
          <h4>Project overview</h4>
          <p>AgriSense is being developed as a practical smart agriculture tool for monitoring soil, water and farm-related conditions. The new photos and video show real device testing and demonstration in agriculture environments.</p>
        </div>

        <div class="modal-detail-section">
          <h4>Problem it solves</h4>
          <p>Many farmers, students and agribusiness projects make decisions without enough data. AgriSense helps reduce guesswork by supporting practical readings, monitoring and future AI-ready recommendations.</p>
        </div>

        <div class="modal-detail-section">
          <h4>Key features</h4>
          <ul>
            <li>Real device demonstration in farm environments</li>
            <li>Supports soil, water and agriculture monitoring concepts</li>
            <li>Can support dashboards, reports and connected systems</li>
            <li>Useful for hydroponics, farms, research and agribusiness pilots</li>
            <li>Demo video included for product explanation</li>
          </ul>
        </div>

        <div class="modal-detail-section">
          <h4>Who can use it</h4>
          <p>Farmers, agribusinesses, schools, researchers, agriculture students, innovation hubs and smart farming demonstration projects.</p>
        </div>

        <div class="modal-detail-section">
          <h4>Current stage & next step</h4>
          <p>AgriSense is presented as a prototype/pre-order enquiry product. The next step is to continue field testing, improve reporting and prepare pilot demonstrations with interested users.</p>
        </div>
      </div>
    `
  },
  enviro6ense: {
    label: "Project 02",
    title: "Enviro6ense",
    image: "images/project-enviro6ense.webp",
    text: "Enviro6ense is an environmental monitoring and safety intelligence concept focused on air quality awareness, fire detection support, GPS/location reporting, connected sensor data and smart alerts for homes, schools, factories, farms and institutions.",
    points: ["Air quality", "Fire alerts", "GPS/location", "Safety monitoring"],
    gallery: ["images/project-enviro6ense.webp", "images/service-prototyping-testing.webp", "images/process-3-build-test.webp"],
    details: `
      <div class="modal-detail-grid project-detail-grid">
        <div class="modal-detail-section">
          <h4>Project overview</h4>
          <p>Enviro6ense is designed as a connected environmental monitoring concept that helps users track safety and environmental conditions. It can support sensor readings, alerts and data review for safer and smarter spaces.</p>
        </div>

        <div class="modal-detail-section">
          <h4>Problem it solves</h4>
          <p>Many spaces do not have simple tools for monitoring environmental risks or early warning signs. Enviro6ense helps improve awareness by collecting sensor data and supporting alerts for important conditions.</p>
        </div>

        <div class="modal-detail-section">
          <h4>Key features</h4>
          <ul>
            <li>Air quality awareness and environmental readings</li>
            <li>Fire detection and safety alert support</li>
            <li>GPS/location reporting concept</li>
            <li>Connected sensor data for monitoring dashboards</li>
            <li>Useful for safety demos, institutions and project pilots</li>
          </ul>
        </div>

        <div class="modal-detail-section">
          <h4>Who can use it</h4>
          <p>Schools, homes, factories, farms, offices, institutions, research teams and organizations that need practical monitoring or safety awareness tools.</p>
        </div>

        <div class="modal-detail-section">
          <h4>Current stage & next step</h4>
          <p>Enviro6ense is at prototype/enquiry stage. The next step is further testing, sensor refinement, dashboard improvement and pilot demonstrations with interested users.</p>
        </div>
      </div>
    `
  },
  startup: {
    label: "Project 03",
    title: "Startup Prototypes",
    image: "images/project-startup-prototypes.webp",
    text: "Startup Prototypes represents how Order Siaw Manufacturing supports founders and SMEs to move from rough ideas into clearer concepts, designs, prototype plans, working samples and early manufacturing preparation.",
    points: ["Idea review", "CAD/design support", "Prototype planning", "Testing & improvement"],
    gallery: ["images/project-startup-prototypes.webp", "images/service-product-development.webp", "images/process-2-design-plan.webp"],
    details: `
      <div class="modal-detail-grid project-detail-grid">
        <div class="modal-detail-section">
          <h4>Project overview</h4>
          <p>This project area focuses on helping startups and SMEs turn product ideas into something that can be designed, tested, improved and presented to customers, partners, competitions or investors.</p>
        </div>

        <div class="modal-detail-section">
          <h4>Problem it solves</h4>
          <p>Many founders have ideas but do not know how to move from concept to prototype. We help reduce confusion by guiding the technical direction, prototype planning and first testing process.</p>
        </div>

        <div class="modal-detail-section">
          <h4>Key support areas</h4>
          <ul>
            <li>Idea clarification and feasibility review</li>
            <li>Design direction and CAD/product concept support</li>
            <li>Prototype planning and sample development support</li>
            <li>Testing, feedback and improvement planning</li>
            <li>Preparation for demo, pitch, pilot or early production</li>
          </ul>
        </div>

        <div class="modal-detail-section">
          <h4>Who can use it</h4>
          <p>Startup founders, SMEs, students, innovation hubs, competition applicants, makers and anyone who needs practical support to develop a product idea.</p>
        </div>

        <div class="modal-detail-section">
          <h4>Current stage & next step</h4>
          <p>This is an active service/project support area. The next step is to collect client ideas, review scope, agree on a development plan and begin prototype support.</p>
        </div>
      </div>
    `
  },
  automation: {
    label: "Project 04",
    title: "Business & Institutional Automation",
    image: "images/project-business-automation.webp",
    text: "Business & Institutional Automation focuses on building digital workflows that improve communication, reminders, reporting, monitoring and operational control for schools, SMEs, offices and project teams.",
    points: ["Workflow automation", "WhatsApp/email systems", "Reports & dashboards", "Operations support"],
    gallery: ["images/project-business-automation.webp", "images/service-mentorship-training.webp", "images/process-1-discuss.webp"],
    details: `
      <div class="modal-detail-grid project-detail-grid">
        <div class="modal-detail-section">
          <h4>Project overview</h4>
          <p>This project area focuses on helping businesses and institutions move from manual processes to smarter digital systems. It can support communication, tracking, reminders, reporting and simple operational automation.</p>
        </div>

        <div class="modal-detail-section">
          <h4>Problem it solves</h4>
          <p>Many organizations lose time because information is scattered across paper, WhatsApp chats, Excel files or manual records. Automation helps make work more organized, faster and easier to monitor.</p>
        </div>

        <div class="modal-detail-section">
          <h4>Key support areas</h4>
          <ul>
            <li>Workflow review and automation planning</li>
            <li>WhatsApp, email and reminder systems</li>
            <li>Dashboards, reports and tracking tools</li>
            <li>Invoice, receipt, fee balance or request workflows</li>
            <li>School, SME and institutional process improvement</li>
          </ul>
        </div>

        <div class="modal-detail-section">
          <h4>Who can use it</h4>
          <p>Schools, SMEs, offices, project teams, training organizations, associations, service providers and institutions that want better digital workflows.</p>
        </div>

        <div class="modal-detail-section">
          <h4>Current stage & next step</h4>
          <p>This is available as a service/project support area. The next step is to review the current workflow, identify what can be automated and build a simple practical system.</p>
        </div>
      </div>
    `
  }
};

const projectCards = document.querySelectorAll(".project-select");
const spotlightImage = document.getElementById("spotlightImage");
const spotlightVideo = document.getElementById("spotlightVideo");
const spotlightVideoSource = document.getElementById("spotlightVideoSource");
const spotlightLabel = document.getElementById("spotlightLabel");
const spotlightTitle = document.getElementById("spotlightTitle");
const spotlightText = document.getElementById("spotlightText");
const spotlightPoints = document.getElementById("spotlightPoints");
const galleryOne = document.getElementById("galleryOne");
const galleryTwo = document.getElementById("galleryTwo");
const galleryThree = document.getElementById("galleryThree");
const openProjectModal = document.getElementById("openProjectModal");
let currentProjectKey = "agrisense";

function updateProjectSpotlight(key, shouldScroll = true) {
  const data = projectData[key];
  if (!data) return;

  currentProjectKey = key;

  projectCards.forEach((card) => {
    card.classList.toggle("active", card.dataset.project === key);
  });

  if (data.video && spotlightVideo && spotlightVideoSource) {
    spotlightVideo.pause();
    spotlightVideoSource.src = data.video;
    spotlightVideo.poster = data.poster || data.image;
    spotlightVideo.load();
    spotlightVideo.style.display = "block";
    spotlightImage.style.display = "none";
    projectVideoBtn.textContent = "▶ Play demo video";
  } else {
    if (spotlightVideo && spotlightVideoSource) {
      spotlightVideo.pause();
      spotlightVideoSource.src = "";
      spotlightVideo.load();
      spotlightVideo.style.display = "none";
    }
    spotlightImage.style.display = "block";
    spotlightImage.src = data.image;
    spotlightImage.alt = data.title + " preview";
    projectVideoBtn.textContent = "▶ Video demo coming soon";
  }

  spotlightLabel.textContent = data.label;
  spotlightTitle.textContent = data.title;
  spotlightText.textContent = data.text;
  spotlightPoints.innerHTML = data.points.map((point) => `<span>${point}</span>`).join("");
  galleryOne.src = data.gallery[0];
  galleryTwo.src = data.gallery[1];
  galleryThree.src = data.gallery[2];

  if (shouldScroll) {
    document.getElementById("projectSpotlight").scrollIntoView({ behavior: "smooth", block: "center" });
  }
}

projectCards.forEach((card) => {
  card.addEventListener("click", () => {
    updateProjectSpotlight(card.dataset.project, true);
  });
});

if (openProjectModal) {
  openProjectModal.addEventListener("click", () => {
    const data = projectData[currentProjectKey];
    openModal(data.title, data.text + " Key focus: " + data.points.join(", ") + ".", data.image, data.details || "");
  });
}

const projectVideoBtn = document.getElementById("projectVideoBtn");
if (projectVideoBtn) {
  projectVideoBtn.addEventListener("click", () => {
    const data = projectData[currentProjectKey];

    if (data.video && spotlightVideo) {
      spotlightVideo.scrollIntoView({ behavior: "smooth", block: "center" });
      spotlightVideo.play();
      return;
    }

    openModal(data.title + " Video Demo", "A video/demo area can be connected here later. For now, this section is prepared so you can add product walkthrough videos, testing clips, customer demos or short promotional videos.", data.image);
  });
}



// V19 Product / Shop catalogue with matching product details
const products = [
  {
    id: "agrisense-probe",
    name: "AgriSense Probe",
    category: "agriculture",
    categoryLabel: "Agriculture",
    image: "images/project-agrisense.webp",
    description: "Smart agriculture monitoring concept for soil and farm data collection.",
    status: "Prototype / Pre-order",
    price: "Request quote",
    delivery: "Timeline after confirmation",
    detailLabel: "Featured Product",
    detailTitle: "AgriSense Probe",
    detailLead: "A smart soil monitoring solution concept for farms, gardens, agribusiness projects, schools and research work. AgriSense helps users understand soil condition and make better farming decisions.",
    detailStatus: "Prototype / Pre-order Enquiry",
    features: [
      ["What it does", "Supports soil moisture and soil condition monitoring."],
      ["AI-ready insight", "Can support AI farming recommendations and reports."],
      ["Who can use it", "Farmers, students, researchers, schools and agribusinesses."],
      ["Order status", "Request demo, quotation or prototype discussion."]
    ],
    howTitle: "How AgriSense works",
    steps: [
      "Place the probe in the soil or target growing area.",
      "Collect useful soil and environmental readings.",
      "Review readings through a dashboard, report or connected system.",
      "Use the insight to improve watering, soil care and farming decisions."
    ]
  },
  {
    id: "enviro6ense-monitor",
    name: "Enviro6ense Monitor",
    category: "environment",
    categoryLabel: "Environment",
    image: "images/project-enviro6ense.webp",
    description: "Environmental monitoring concept for air quality, safety alerts and connected sensors.",
    status: "Prototype / Enquiry",
    price: "Request quote",
    delivery: "Timeline after confirmation",
    detailLabel: "Featured Product",
    detailTitle: "Enviro6ense Monitor",
    detailLead: "Enviro6ense is an environmental monitoring and safety intelligence concept for connected sensor data, air quality awareness, fire detection support, GPS/location reporting and smart alerts.",
    detailStatus: "Prototype / Enquiry",
    features: [
      ["What it does", "Supports environmental readings and connected sensor monitoring."],
      ["Safety focus", "Can support fire alerts, air quality awareness and location reporting."],
      ["Who can use it", "Schools, factories, institutions, farms, homes and project teams."],
      ["Order status", "Request quotation, demo discussion or prototype support."]
    ],
    howTitle: "How Enviro6ense works",
    steps: [
      "Install the monitor in the target environment or project area.",
      "Collect environmental and safety-related sensor readings.",
      "Send readings to a dashboard, alert system or connected platform.",
      "Use the information to improve monitoring, safety response and reporting."
    ]
  },
  {
    id: "startup-prototype-package",
    name: "Startup Prototype Package",
    category: "prototyping",
    categoryLabel: "Prototyping",
    image: "images/project-startup-prototypes.webp",
    description: "Support package for founders who want to move from idea to product prototype.",
    status: "Available as service",
    price: "Request quote",
    delivery: "Based on project scope",
    detailLabel: "Service Package",
    detailTitle: "Startup Prototype Package",
    detailLead: "A practical support package for startups and SMEs who need help turning an idea into a clear concept, design direction, working prototype and early manufacturing plan.",
    detailStatus: "Available as Service",
    features: [
      ["Idea review", "We help clarify the product idea, target user and problem being solved."],
      ["Prototype planning", "We guide the design, materials, basic components and development path."],
      ["Testing support", "We help review prototype performance and identify improvements."],
      ["Startup-ready", "Useful for founders, students, innovators and early-stage SMEs."]
    ],
    howTitle: "How the startup prototype package works",
    steps: [
      "Discuss your idea and product goal.",
      "Prepare the design direction and prototype plan.",
      "Build or support the first working sample.",
      "Improve the product and prepare next development steps."
    ]
  },
  {
    id: "automation-setup",
    name: "Business Automation Setup",
    category: "automation",
    categoryLabel: "Automation",
    image: "images/project-business-automation.webp",
    description: "Digital automation setup for businesses and institutions to improve workflow and reporting.",
    status: "Available as service",
    price: "Request quote",
    delivery: "Based on project scope",
    detailLabel: "Automation Service",
    detailTitle: "Business Automation Setup",
    detailLead: "A digital automation service for businesses, schools and institutions that want to improve communication, task tracking, reporting, alerts and workflow efficiency.",
    detailStatus: "Available as Service",
    features: [
      ["Workflow review", "We study the current process and identify what can be automated."],
      ["Smart communication", "Can support WhatsApp, email, reminders and response flows."],
      ["Reports & tracking", "Helps teams monitor records, requests, tasks and operations."],
      ["Institution-ready", "Useful for schools, SMEs, offices and project teams."]
    ],
    howTitle: "How business automation works",
    steps: [
      "Review the manual process and pain points.",
      "Design a simple automation flow.",
      "Build the workflow, dashboard, reminder or communication tool.",
      "Test, improve and hand over the system for use."
    ]
  },
  {
    id: "cad-product-design",
    name: "CAD & Product Design Support",
    category: "prototyping",
    categoryLabel: "Prototyping",
    image: "images/service-product-development.webp",
    description: "Product design, CAD concept development and early manufacturing planning.",
    status: "Available as service",
    price: "Request quote",
    delivery: "Based on project scope",
    detailLabel: "Design Service",
    detailTitle: "CAD & Product Design Support",
    detailLead: "Design support for innovators who need sketches, CAD concepts, product visuals, technical planning and a clearer development path before prototyping or production.",
    detailStatus: "Available as Service",
    features: [
      ["CAD concept", "Create or improve digital product design ideas."],
      ["Technical planning", "Review dimensions, materials, parts and build approach."],
      ["Prototype-ready", "Prepare the concept for testing or sample development."],
      ["Visual support", "Useful for proposals, pitch decks and product explanation."]
    ],
    howTitle: "How CAD & product design support works",
    steps: [
      "Share your product idea, sketch or reference image.",
      "We review the function, size and expected use.",
      "We prepare a clearer concept or design direction.",
      "You use the design for prototyping, discussion or manufacturing planning."
    ]
  },
  {
    id: "mentorship-training",
    name: "Innovation Mentorship & Training",
    category: "training",
    categoryLabel: "Training",
    image: "images/service-mentorship-training.webp",
    description: "Training and mentorship for students, startups and SMEs building technical products.",
    status: "Available as service",
    price: "Request quote",
    delivery: "Scheduled sessions",
    detailLabel: "Training Service",
    detailTitle: "Innovation Mentorship & Training",
    detailLead: "Practical training and mentorship for students, startups and SMEs who want to learn product development, prototyping, automation and innovation skills.",
    detailStatus: "Scheduled Sessions",
    features: [
      ["Hands-on learning", "Training focuses on practical skills and real examples."],
      ["Startup guidance", "Supports founders with product thinking and development planning."],
      ["Technical mentoring", "Useful for students, makers, SMEs and project teams."],
      ["Flexible delivery", "Can be arranged as workshops, coaching or project support."]
    ],
    howTitle: "How mentorship & training works",
    steps: [
      "Identify the training need or project goal.",
      "Agree on the training format and schedule.",
      "Deliver practical sessions with examples and exercises.",
      "Support participants with next steps and improvement guidance."
    ]
  }
];

const productGrid = document.getElementById("productGrid");
const productSearch = document.getElementById("productSearch");
const filterButtons = document.querySelectorAll(".filter-btn");
const orderModal = document.getElementById("orderModal");
const orderOverlay = document.getElementById("orderOverlay");
const orderClose = document.getElementById("orderClose");
const orderTitle = document.getElementById("orderTitle");
const orderDescription = document.getElementById("orderDescription");
const customerName = document.getElementById("customerName");
const customerPhone = document.getElementById("customerPhone");
const orderQuantity = document.getElementById("orderQuantity");
const orderNotes = document.getElementById("orderNotes");
const sendWhatsappOrder = document.getElementById("sendWhatsappOrder");
const sendEmailOrder = document.getElementById("sendEmailOrder");

const productDetailPanel = document.getElementById("productDetailPanel");
const detailImage = document.getElementById("detailImage");
const detailStatus = document.getElementById("detailStatus");
const detailLabel = document.getElementById("detailLabel");
const detailTitle = document.getElementById("detailTitle");
const detailLead = document.getElementById("detailLead");
const detailFeatures = document.getElementById("detailFeatures");
const detailHowTitle = document.getElementById("detailHowTitle");
const detailSteps = document.getElementById("detailSteps");
const detailOrderBtn = document.getElementById("detailOrderBtn");
const detailPreviewBtn = document.getElementById("detailPreviewBtn");

let activeFilter = "agriculture";
let selectedProduct = null;
let activeDetailProductId = "agrisense-probe";

function getFilteredProducts() {
  const searchTerm = (productSearch?.value || "").toLowerCase().trim();

  return products.filter((product) => {
    const matchesFilter = activeFilter === "all" || product.category === activeFilter;
    const searchBlob = `${product.name} ${product.categoryLabel} ${product.description} ${product.detailLead}`.toLowerCase();
    const matchesSearch = searchBlob.includes(searchTerm);
    return matchesFilter && matchesSearch;
  });
}

function updateProductDetail(productId, shouldScroll = false) {
  const product = products.find((item) => item.id === productId) || products[0];
  activeDetailProductId = product.id;

  if (!productDetailPanel) return;

  detailImage.src = product.image;
  detailImage.alt = `${product.name} preview`;
  detailStatus.textContent = product.detailStatus;
  detailLabel.textContent = product.detailLabel;
  detailTitle.textContent = product.detailTitle;
  detailLead.textContent = product.detailLead;

  detailFeatures.innerHTML = product.features.map(([title, text]) => `
    <div>
      <strong>${title}</strong>
      <span>${text}</span>
    </div>
  `).join("");

  detailHowTitle.textContent = product.howTitle;
  detailSteps.innerHTML = product.steps.map((step) => `<li>${step}</li>`).join("");

  if (detailOrderBtn) {
    detailOrderBtn.textContent = product.id === "agrisense-probe"
      ? "Request AgriSense Quote"
      : product.id === "enviro6ense-monitor"
        ? "Request Enviro6ense Quote"
        : "Request Quote";
  }

  if (shouldScroll) {
    productDetailPanel.scrollIntoView({ behavior: "smooth", block: "center" });
  }
}

function renderProducts() {
  if (!productGrid) return;

  const filtered = getFilteredProducts();

  if (filtered.length === 0) {
    productGrid.innerHTML = `<div class="no-products">No matching products found. Try another search.</div>`;
    return;
  }

  productGrid.innerHTML = filtered.map((product) => `
    <article class="product-card" data-product="${product.id}">
      <div class="product-image">
        <img loading="lazy" decoding="async" src="${product.image}" alt="${product.name}">
      </div>

      <div class="product-content">
        <span class="product-category">${product.categoryLabel}</span>
        <h3>${product.name}</h3>
        <p>${product.description}</p>

        <div class="product-meta">
          <span><strong>Status</strong> ${product.status}</span>
          <span><strong>Price</strong> ${product.price}</span>
          <span><strong>Delivery</strong> ${product.delivery}</span>
        </div>

        <div class="product-actions">
          <button class="btn btn-primary order-product-btn" data-product="${product.id}">Order / Request Quote</button>
          <button class="btn btn-dark view-product-detail-btn" data-product="${product.id}">View Details</button>
        </div>
      </div>
    </article>
  `).join("");

  updateProductDetail(filtered[0].id, false);

  document.querySelectorAll(".product-card").forEach((card) => {
    card.addEventListener("click", (e) => {
      if (e.target.closest("button")) return;
      updateProductDetail(card.dataset.product, true);
    });
  });

  document.querySelectorAll(".order-product-btn").forEach((button) => {
    button.addEventListener("click", () => {
      updateProductDetail(button.dataset.product, false);
      openOrderModal(button.dataset.product);
    });
  });

  document.querySelectorAll(".view-product-detail-btn").forEach((button) => {
    button.addEventListener("click", () => {
      updateProductDetail(button.dataset.product, true);
    });
  });
}

function openOrderModal(productId) {
  updateProductDetail(productId, false);
  selectedProduct = products.find((item) => item.id === productId);
  if (!selectedProduct) return;

  orderTitle.textContent = selectedProduct.name;
  orderDescription.textContent = `${selectedProduct.description} Order Siaw Manufacturing will confirm availability, price, timeline and payment instructions before any final purchase.`;

  orderQuantity.value = "";
  orderNotes.value = "";
  orderModal.classList.add("show");
  orderModal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
}

function closeOrderModal() {
  orderModal.classList.remove("show");
  orderModal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}

function buildOrderMessage() {
  const name = customerName.value.trim() || "Not provided";
  const phone = customerPhone.value.trim() || "Not provided";
  const quantity = orderQuantity.value.trim() || "Not provided";
  const notes = orderNotes.value.trim() || "No extra notes";

  return `Hello Order Siaw Manufacturing, I want to make an order/request quote.

Product/Service: ${selectedProduct?.name || "Not selected"}
Category: ${selectedProduct?.categoryLabel || "Not selected"}
Name: ${name}
Phone/WhatsApp: ${phone}
Quantity/Package: ${quantity}
Notes: ${notes}`;
}

if (productSearch) {
  productSearch.addEventListener("input", renderProducts);
}

filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
    filterButtons.forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    activeFilter = button.dataset.filter;
    renderProducts();
  });
});

if (detailOrderBtn) {
  detailOrderBtn.addEventListener("click", () => {
    openOrderModal(activeDetailProductId);
  });
}

if (detailPreviewBtn) {
  detailPreviewBtn.addEventListener("click", () => {
    const product = products.find((item) => item.id === activeDetailProductId) || products[0];
    openModal(product.name, `${product.detailLead} Status: ${product.status}. Price: ${product.price}.`, product.image);
  });
}

if (orderOverlay) orderOverlay.addEventListener("click", closeOrderModal);
if (orderClose) orderClose.addEventListener("click", closeOrderModal);

if (sendWhatsappOrder) {
  sendWhatsappOrder.addEventListener("click", (e) => {
    e.preventDefault();
    const message = encodeURIComponent(buildOrderMessage());
    window.open(`https://wa.me/233248984746?text=${message}`, "_blank");
  });
}

if (sendEmailOrder) {
  sendEmailOrder.addEventListener("click", (e) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Order Request - ${selectedProduct?.name || "Order Siaw Product"}`);
    const body = encodeURIComponent(buildOrderMessage());
    window.location.href = `mailto:ordersiaw96@gmail.com?subject=${subject}&body=${body}`;
  });
}

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && orderModal?.classList.contains("show")) {
    closeOrderModal();
  }
});

renderProducts();



// V11 scroll-triggered repeat animation for Our Services
const serviceGrid = document.querySelector(".service-animate");

if (serviceGrid && "IntersectionObserver" in window) {
  const serviceObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        serviceGrid.classList.add("services-in-view");
      } else {
        serviceGrid.classList.remove("services-in-view");
      }
    });
  }, {
    threshold: 0.18
  });

  serviceObserver.observe(serviceGrid);
} else if (serviceGrid) {
  serviceGrid.classList.add("services-in-view");
}



// V12 scroll-triggered repeat animation for Featured Projects
const projectGridAnimation = document.querySelector(".project-animate");
const projectSpotlightAnimation = document.querySelector(".spotlight-animate");

if (projectGridAnimation && "IntersectionObserver" in window) {
  const projectObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        projectGridAnimation.classList.add("projects-in-view");
      } else {
        projectGridAnimation.classList.remove("projects-in-view");
      }
    });
  }, {
    threshold: 0.18
  });

  projectObserver.observe(projectGridAnimation);
} else if (projectGridAnimation) {
  projectGridAnimation.classList.add("projects-in-view");
}

if (projectSpotlightAnimation && "IntersectionObserver" in window) {
  const spotlightObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        projectSpotlightAnimation.classList.add("spotlight-in-view");
      } else {
        projectSpotlightAnimation.classList.remove("spotlight-in-view");
      }
    });
  }, {
    threshold: 0.16
  });

  spotlightObserver.observe(projectSpotlightAnimation);
} else if (projectSpotlightAnimation) {
  projectSpotlightAnimation.classList.add("spotlight-in-view");
}



// V13 scroll-triggered repeat animation for Products & Solutions
const shopToolsAnimation = document.querySelector(".shop-tools-animate");
const productGridAnimation = document.querySelector(".product-animate");

function restartProductCardsAnimation() {
  if (!productGridAnimation) return;

  productGridAnimation.classList.remove("products-in-view");

  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      const rect = productGridAnimation.getBoundingClientRect();
      const isVisible = rect.top < window.innerHeight * 0.82 && rect.bottom > window.innerHeight * 0.12;
      if (isVisible) {
        productGridAnimation.classList.add("products-in-view");
      }
    });
  });
}

if (shopToolsAnimation && "IntersectionObserver" in window) {
  const shopToolsObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        shopToolsAnimation.classList.add("products-tools-in-view");
      } else {
        shopToolsAnimation.classList.remove("products-tools-in-view");
      }
    });
  }, {
    threshold: 0.20
  });

  shopToolsObserver.observe(shopToolsAnimation);
} else if (shopToolsAnimation) {
  shopToolsAnimation.classList.add("products-tools-in-view");
}

if (productGridAnimation && "IntersectionObserver" in window) {
  const productObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        productGridAnimation.classList.add("products-in-view");
      } else {
        productGridAnimation.classList.remove("products-in-view");
      }
    });
  }, {
    threshold: 0.12
  });

  productObserver.observe(productGridAnimation);
} else if (productGridAnimation) {
  productGridAnimation.classList.add("products-in-view");
}

// Re-run product animation whenever search/filter changes and new product cards are rendered.
if (productSearch) {
  productSearch.addEventListener("input", restartProductCardsAnimation);
}

filterButtons.forEach((button) => {
  button.addEventListener("click", restartProductCardsAnimation);
});



// V14 scroll-triggered repeat animation for From idea to working product
const processGridAnimation = document.querySelector(".process-animate");

if (processGridAnimation && "IntersectionObserver" in window) {
  const processObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        processGridAnimation.classList.add("process-in-view");
      } else {
        processGridAnimation.classList.remove("process-in-view");
      }
    });
  }, {
    threshold: 0.18
  });

  processObserver.observe(processGridAnimation);
} else if (processGridAnimation) {
  processGridAnimation.classList.add("process-in-view");
}



// V31 Quick contact / request quote center with smart message templates
const requestOptions = document.querySelectorAll(".request-option");
const quickName = document.getElementById("quickName");
const quickPhone = document.getElementById("quickPhone");
const quickService = document.getElementById("quickService");
const quickMessage = document.getElementById("quickMessage");
const quickWhatsapp = document.getElementById("quickWhatsapp");
const quickEmail = document.getElementById("quickEmail");

const requestTemplates = {
  "Product quote": "Hello Order Siaw Manufacturing, I want to request a product quote. Please help me confirm availability, price, timeline and payment instructions.",
  "Prototype idea": "Hello Order Siaw Manufacturing, I want to discuss a prototype idea. I need support to move from idea stage to a working prototype. Please let me know the next steps and what information you need from me.",
  "Automation support": "Hello Order Siaw Manufacturing, I want to discuss automation support for a business, school or institutional workflow. Please advise what information you need to understand the process and propose a solution.",
  "Training or mentorship": "Hello Order Siaw Manufacturing, I want to request training or mentorship support. Please share the available options, possible schedule and cost.",
  "Partnership discussion": "Hello Order Siaw Manufacturing, I want to discuss a partnership or collaboration opportunity. Please let me know how we can proceed.",
  "AgriSense Probe": "Hello Order Siaw Manufacturing, I want to request information and a quote for the AgriSense Probe. Please confirm availability, price, timeline and demo/pre-order options.",
  "Enviro6ense Monitor": "Hello Order Siaw Manufacturing, I want to request information and a quote for the Enviro6ense Monitor. Please confirm availability, price, timeline and demo/prototype options.",
  "Startup Prototype Package": "Hello Order Siaw Manufacturing, I want to request the Startup Prototype Package. I need support to develop an idea into a prototype. Please advise the process, cost and timeline.",
  "Business Automation Setup": "Hello Order Siaw Manufacturing, I want to request Business Automation Setup. Please help me review my workflow and advise the best automation solution.",
  "CAD & Product Design Support": "Hello Order Siaw Manufacturing, I want to request CAD & Product Design Support. Please advise what details, sketches or references you need from me.",
  "Innovation Mentorship & Training": "Hello Order Siaw Manufacturing, I want to request Innovation Mentorship & Training. Please share the training/mentorship options, schedule and cost."
};

let lastAutoRequestMessage = "";

function setQuickRequest(type, forceReplace = false) {
  if (!quickService || !quickMessage) return;
  quickService.value = type;
  const template = requestTemplates[type] || `Hello Order Siaw Manufacturing, I want to discuss ${type.toLowerCase()}. Please let me know the next steps.`;
  const currentMessage = quickMessage.value.trim();
  if (forceReplace || currentMessage === "" || currentMessage === lastAutoRequestMessage) {
    quickMessage.value = template;
    lastAutoRequestMessage = template;
  }
}

requestOptions.forEach((button) => {
  button.addEventListener("click", () => {
    requestOptions.forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    setQuickRequest(button.dataset.request, true);
  });
});

if (quickService) {
  quickService.addEventListener("change", () => {
    setQuickRequest(quickService.value, true);
  });
}

function buildQuickRequestMessage() {
  const name = quickName?.value.trim() || "Not provided";
  const phone = quickPhone?.value.trim() || "Not provided";
  const service = quickService?.value || "General enquiry";
  const message = quickMessage?.value.trim() || requestTemplates[service] || "I want to make an enquiry.";

  return `Hello Order Siaw Manufacturing, I want to make a request.

Name: ${name}
Phone/WhatsApp: ${phone}
Product/Service: ${service}
Message: ${message}

Please confirm availability, price, timeline and payment instructions.`;
}

if (quickWhatsapp) {
  quickWhatsapp.addEventListener("click", (e) => {
    e.preventDefault();
    const message = encodeURIComponent(buildQuickRequestMessage());
    window.open(`https://wa.me/233248984746?text=${message}`, "_blank");
  });
}

if (quickEmail) {
  quickEmail.addEventListener("click", (e) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Order Siaw Request - ${quickService?.value || "General Enquiry"}`);
    const body = encodeURIComponent(buildQuickRequestMessage());
    window.location.href = `mailto:ordersiaw96@gmail.com?subject=${subject}&body=${body}`;
  });
}

setQuickRequest("Product quote", true);


// V25 Why Work With Us details
const whyDetails = {
  practical: {
    title: "Practical Engineering Support",
    text: "We focus on practical engineering support that helps clients understand what can realistically be designed, built, tested and improved.",
    details: `
      <div class="modal-detail-grid">
        <div class="modal-detail-section">
          <h4>Why it matters</h4>
          <p>Many ideas sound good but need technical review before money is spent. We help clients understand the practical path, likely challenges and best next step.</p>
        </div>
        <div class="modal-detail-section">
          <h4>What this means for you</h4>
          <ul>
            <li>Clearer product direction</li>
            <li>Better technical decisions</li>
            <li>Reduced trial-and-error</li>
            <li>More realistic prototype planning</li>
          </ul>
        </div>
      </div>
    `
  },
  startup: {
    title: "Startup-Friendly Process",
    text: "We support founders and early-stage businesses with a simple step-by-step process from idea to prototype and early production planning.",
    details: `
      <div class="modal-detail-grid">
        <div class="modal-detail-section">
          <h4>Why it matters</h4>
          <p>Startups often need direction, not complicated engineering language. We break the process into clear steps so founders know what to do next.</p>
        </div>
        <div class="modal-detail-section">
          <h4>What this means for you</h4>
          <ul>
            <li>Idea review and development path</li>
            <li>Prototype planning support</li>
            <li>Testing and improvement guidance</li>
            <li>Preparation for demos, pitches or pilots</li>
          </ul>
        </div>
      </div>
    `
  },
  affordable: {
    title: "Cost-Conscious Development",
    text: "We think about budget, materials, local availability and practical production methods before building.",
    details: `
      <div class="modal-detail-grid">
        <div class="modal-detail-section">
          <h4>Why it matters</h4>
          <p>Product development can become expensive quickly. We help clients think through cost early so they avoid unnecessary spending.</p>
        </div>
        <div class="modal-detail-section">
          <h4>What this means for you</h4>
          <ul>
            <li>Material and component guidance</li>
            <li>Simple prototype approach</li>
            <li>Cost-saving recommendations</li>
            <li>Clearer scope before work begins</li>
          </ul>
        </div>
      </div>
    `
  },
  automation: {
    title: "Product + Automation Thinking",
    text: "We support both physical product development and digital automation workflows for businesses and institutions.",
    details: `
      <div class="modal-detail-grid">
        <div class="modal-detail-section">
          <h4>Why it matters</h4>
          <p>Modern solutions often need both hardware and software thinking. We can support products, dashboards, WhatsApp flows, reminders, reports and simple automation tools.</p>
        </div>
        <div class="modal-detail-section">
          <h4>What this means for you</h4>
          <ul>
            <li>Product and digital workflow support</li>
            <li>WhatsApp/email automation concepts</li>
            <li>Dashboards and reporting ideas</li>
            <li>Better process tracking for teams</li>
          </ul>
        </div>
      </div>
    `
  },
  training: {
    title: "Hands-On Mentorship",
    text: "We guide students, startups, SMEs and teams with practical learning and project improvement support.",
    details: `
      <div class="modal-detail-grid">
        <div class="modal-detail-section">
          <h4>Why it matters</h4>
          <p>Many people need hands-on guidance to understand how to move from learning to building. We support practical skills and real project development.</p>
        </div>
        <div class="modal-detail-section">
          <h4>What this means for you</h4>
          <ul>
            <li>Innovation and product mentoring</li>
            <li>Project review and improvement</li>
            <li>Technical training support</li>
            <li>Guidance for demos and competitions</li>
          </ul>
        </div>
      </div>
    `
  },
  ghana: {
    title: "Built for Local Innovation",
    text: "We understand the realities of developing products in Ghana and similar markets, including cost, materials, access and early-stage support needs.",
    details: `
      <div class="modal-detail-grid">
        <div class="modal-detail-section">
          <h4>Why it matters</h4>
          <p>Product development support should match the environment where the product will be used. We consider local context, affordability and practical deployment.</p>
        </div>
        <div class="modal-detail-section">
          <h4>What this means for you</h4>
          <ul>
            <li>Local-context product thinking</li>
            <li>Practical material and supplier considerations</li>
            <li>Support for early-stage innovators</li>
            <li>Solutions that can be tested in real environments</li>
          </ul>
        </div>
      </div>
    `
  }
};

const whyCards = document.querySelectorAll(".why-card");

whyCards.forEach((card) => {
  card.addEventListener("click", () => {
    const item = whyDetails[card.dataset.why];
    if (!item) return;
    openModal(item.title, item.text, "images/about-us.webp", item.details);
  });
});

const whyGridAnimation = document.querySelector(".why-animate");

if (whyGridAnimation && "IntersectionObserver" in window) {
  const whyObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        whyGridAnimation.classList.add("why-in-view");
      } else {
        whyGridAnimation.classList.remove("why-in-view");
      }
    });
  }, {
    threshold: 0.15
  });

  whyObserver.observe(whyGridAnimation);
} else if (whyGridAnimation) {
  whyGridAnimation.classList.add("why-in-view");
}



// V26 active navigation and back-to-top
const sectionIdsForNav = ["home", "about", "why-us", "services", "projects", "products", "process", "contact"];
const navAnchors = document.querySelectorAll(".nav-links a");
const backToTop = document.getElementById("backToTop");

function updateActiveNav() {
  let currentId = "home";

  sectionIdsForNav.forEach((id) => {
    const section = document.getElementById(id);
    if (!section) return;

    const rect = section.getBoundingClientRect();
    if (rect.top <= 140 && rect.bottom >= 140) {
      currentId = id;
    }
  });

  navAnchors.forEach((link) => {
    link.classList.toggle("active", link.getAttribute("href") === `#${currentId}`);
  });

  if (backToTop) {
    backToTop.classList.toggle("show", window.scrollY > 600);
  }
}

window.addEventListener("scroll", updateActiveNav, { passive: true });
window.addEventListener("load", updateActiveNav);

if (backToTop) {
  backToTop.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
}

navAnchors.forEach((link) => {
  link.addEventListener("click", () => {
    if (navLinks?.classList.contains("show")) {
      navLinks.classList.remove("show");
    }
  });
});



// V27 small mobile polish helpers
document.documentElement.classList.add("js-ready");

// Prevent background jump when tapping floating buttons repeatedly
document.querySelectorAll(".floating-whatsapp, .back-to-top").forEach((button) => {
  button.addEventListener("touchstart", () => {}, { passive: true });
});
